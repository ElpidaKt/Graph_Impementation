#include"AVL.hpp"
#include <iostream>
#include <string>
#include <functional>
#include <string.h>
#include <sstream>

using namespace std;

AVL::Node::Node(const string& str, Node *parent, Node *left, Node *right){
    this->element = str;
    this->parent = parent;
    this->left = left;
    this->right = right;
}


AVL::Node * AVL::Node::getParent() const{
    return parent;
}

AVL::Node* AVL::Node::getLeft() const{
    return left; 
} 

AVL::Node* AVL::Node::getRight() const{
    return right;
}

string  AVL::Node::getElement() const{
    return element;
}

int  AVL::Node::getHeight() const{
    return height;
}

void  AVL::Node::setLeft(AVL::Node * cur_node) {
    this->left = cur_node;
    if (this->left != NULL)
        this->left->setParent(this);
    
}

void  AVL::Node::setRight(AVL::Node * cur_node) {
    this->right = cur_node;
    if (this->right != NULL)
        this->right->setParent(this);
}

void  AVL::Node::setParent(AVL::Node * cur_node) {
    this->parent = cur_node;
    
}

void  AVL::Node::setElement(string contents) {
    this->element = contents;
    
}

void  AVL::Node::setHeight(int num) {
    this->height = num;
    
}

bool  AVL::Node::isLeft() const{

    
    if(this->parent == NULL){
        return false;
        
    }
    else if(this->parent->left != NULL && this->parent->left == this){
        return true;
    }
    
    return false;

    
}


bool  AVL::Node::isRight() const{

    
    if(this->parent == NULL){
        return false;
        
    }
    else if(this->parent->right != NULL && this->parent->right == this){
        return true;
    }

    return false;
    
}

bool  AVL::isRoot(Node* nd) {

    if(nd->getParent() == NULL){
        return true;
    }
    else{
        return false;
    }
}

bool  AVL::hasRight(Node *nd){
    if(nd->getRight() != NULL){
        return true;
    }
    else{
        return false;
    }
}
   
bool  AVL::hasLeft(Node *nd){
    if(nd->getLeft() != NULL){
        return true;
    }
    else{
        return false;
    }
}
       

int  AVL::Node::rightChildHeight() const{
    if(this->right)
        return this->right->getHeight();
    
    return 0;

}

int  AVL::Node::leftChildHeight() const{
    if(this->left)
        return this->left->getHeight();
    
    return 0;


}

int  AVL::Node::updateHeight(){
    int right_height, left_height;
    
    if(this->getParent()){
    
        right_height = rightChildHeight();

        
        
        left_height = leftChildHeight();
    
        
        if(right_height > left_height){
            return right_height + 1;
            
        }
        else{
            return left_height + 1;
        }
    }
    else {
        
        return 0;
    }
}



AVL::Node * AVL::CreateNode(string data){
    Node *newNode = new AVL::Node(data,NULL, NULL, NULL);
    newNode->setHeight(1);

    return newNode;
}







//constructors

AVL::AVL(){
    this->root = NULL;
	this->size = 0;
}

AVL::Node* AVL::Root(){
	return(root);
}

AVL::AVL(AVL& copy_tree){
	this->root = NULL;
    this->size = 0;
	this->Create_new_tree(copy_tree.root);//, this->root);
}

void AVL::Create_new_tree(Node* treeNode){//, Node* myNode){
	
		
	//myNode = CreateNode(treeNode->getElement());
    //cout << treeNode << endl;
    if(treeNode != NULL){
        this->add(treeNode->getElement());
    

        if(treeNode->getLeft() != NULL){
            Create_new_tree(treeNode->getLeft());//, myNode->getLeft());
        }
        
        if(treeNode->getRight() != NULL){
            Create_new_tree(treeNode->getRight());//, myNode->getRight());
        }
    }
}

AVL AVL::makeTreerec(Node* node, AVL* myTree){
    myTree->add(node->getElement());
    
    if(node->getLeft() != NULL){
		makeTreerec(node->getLeft(), myTree);
	}
	
	if(node->getRight() != NULL){
		makeTreerec(node->getRight(), myTree);
	}
    
    return *myTree;
}

bool AVL::Node::isBalanced(){
	int rightHeight,leftHeight;
	
	if(this->right == NULL){
		rightHeight = 0;
	}
	else{
		rightHeight = this->right->getHeight();
	}
	if(this->left == NULL){
		leftHeight =0;
	}
	else{
		leftHeight = this->left->getHeight();
	}
		
	if(rightHeight > leftHeight){
		if(rightHeight - leftHeight >= 2){
			return false;
		}
		else 
			return true;
	}
	else if(rightHeight < leftHeight){
		if(leftHeight - rightHeight >= 2){
			return false;
		}
		else 
			return true;
	}
	else 
		return true;
	
}


int AVL::balance_res(Node *nd){
    if (nd == NULL) {
        return 0; 
    }
    else{
        if(nd->getLeft() != NULL && nd->getRight() != NULL){
            return nd->getLeft()->getHeight() - nd->getRight()->getHeight(); 
            
        }
        else if(nd->getLeft() == NULL && nd->getRight() != NULL){
            return - nd->getRight()->getHeight();
        }
        else if(nd->getRight() == NULL && nd->getLeft() != NULL){
            return nd->getLeft()->getHeight();
        }
    }
    return 0;
}

bool AVL::contains(string content){
    bool res;
    res = search(this->root, content);
    
    return res;
}

bool AVL::search(Node* cur, string key) {
    bool result_left, result_right;
    
    if(cur!=NULL){  
        if (key.compare(cur->getElement()) == 0) {
           return true;
        } 
        if(cur->getLeft()!= NULL){
            result_left = search(cur->getLeft(), key);
        }
        if(cur->getRight()!= NULL){
            result_right = search(cur->getRight(), key);
        }
        
        if(result_left == true || result_right == true){
            
            return true;
        }
        
        else{
            return false;
        }
    }
    else{
        return false;
    }
} 


bool AVL::add(string value ) {

    if(contains(value)){
        return false;
    }
    
    
    root = add_node(root, value);
    return true;
    
}

AVL::Node* AVL::add_node(Node *prevroot, string value){
    
    if(prevroot == NULL){
        prevroot = CreateNode(value);
        return prevroot;
        
    }
    
    if(prevroot->getElement().compare(value)==0){
        return prevroot;
    }
    
    if(value.compare(prevroot->getElement())< 0){
        if(prevroot->getLeft() == NULL){
            Node *newnode = CreateNode(value);
            newnode->setParent(prevroot);
            prevroot->setLeft(add_node(newnode, value));

        }
        else{
            prevroot->setLeft(add_node(prevroot->getLeft(), value));
        }
    }
    
    else if(value.compare(prevroot->getElement())>0){
        if(prevroot->getRight() == NULL){
            Node *newnode = CreateNode(value);
            newnode->setParent(prevroot);
            prevroot->setRight(add_node(newnode, value));
            
        }
        else{
            prevroot->setRight(add_node(prevroot->getRight(), value));
        }
    }
    prevroot->setHeight(prevroot->updateHeight());
    
    bool bal = prevroot->isBalanced();
    int balance = balance_res(prevroot);
    
    if(!bal){
        if(balance > 1 && value.compare(prevroot->getLeft()->getElement())<0){
            return rotateRight(prevroot);
        }
        
        else if(balance < -1 && value.compare(prevroot->getRight()->getElement())>0 ){
            return rotateLeft(prevroot);
        }
        else if(balance > 1 && value.compare(prevroot->getLeft()->getElement())>0){
            prevroot->setLeft(rotateLeft(prevroot->getLeft()));
            return rotateRight(prevroot);
        }
        else if(balance < -1 && value.compare(prevroot->getRight()->getElement())<0){
            prevroot->setRight(rotateRight(prevroot->getRight()));
            return rotateLeft(prevroot);
        }
    }
    
    return prevroot;
    
}

AVL::Node * AVL::thelastleft(Node* node) 
{ 
    Node* current = node; 
  
    /* loop down to find the leftmost leaf */
    while (current->getLeft() != NULL) 
        current = current->getLeft(); 
  
    return current; 
} 

bool AVL::rmv(string value ) {
    if(!contains(value)){
            return false;
    }
        
    root = rmv_node(root, value);
    return true;
    
}

AVL::Node* AVL::rmv_node(Node *root, string value){
    if(root == NULL){
        return root;
    }
    
    if(value.compare(root->getElement())<0){
        root->setLeft(rmv_node(root->getLeft(), value));
    }
    
    else if(value.compare(root->getElement())>0){
        root->setRight(rmv_node(root->getRight(), value));
    }
    else{
        if(root->getLeft() == NULL  || root->getRight() == NULL){
            Node *temp = root->getLeft()? root->getLeft() : root->getRight(); 
            if(temp == NULL){
                temp = root;
                root = NULL;
            }
            else{
                *root = *temp;
            }
            
            free(temp);
            
        }
        else{
            Node* temp = thelastleft(root->getRight());
            root->setElement(temp->getElement());
            root->setRight(rmv_node(root->getRight(), temp->getElement())); 
        }
    }
    
    if (root == NULL)
        return root; 
    root->setHeight(root->updateHeight());
    
    bool bal = root->isBalanced();
    int balance = balance_res(root);
    
    if(!bal){
        if(balance > 1 && balance_res(root->getLeft())>=0){
            return rotateRight(root);
        }
        
        if(balance > 1 && balance_res(root->getLeft())<0){
            root->setLeft(rotateLeft(root->getLeft())); 
            return rotateRight(root); 
        }
        
        if(balance < -1 && balance_res(root->getRight())<=0){
            return rotateLeft(root);
        }
        
        if(balance < -1 && balance_res(root->getRight())>0){
            root->setRight(rotateRight(root->getRight())); 
            return rotateLeft(root); 
        }
        
    }
    
    return root;
    
}

AVL::Node *AVL::deleteTree(Node *node) 
{ 
    if (node != NULL){
        this->rmv(node->getElement());
        return NULL;
    
        //cout<< "eimaste edv"<<endl;
        if(node->getLeft() != NULL){
            node->setLeft(deleteTree(node->getLeft())); 
        }
        if(node->getRight() != NULL){
            node->setRight(deleteTree(node->getRight())); 
        }
    }
    return NULL;
} 

void AVL::addTree(Node *node) 
{ 
    if (node != NULL){
        this->add(node->getElement());
    
        if(node->getLeft() != NULL){
            addTree(node->getLeft()); 
        }
        if(node->getRight() != NULL){
            addTree(node->getRight()); 
        }
    }
 
}

AVL::Node* AVL::rotateLeft(Node *prevroot){
    
    Node *cur = prevroot->getRight();
    Node *l = cur->getLeft();
    
    cur->setLeft(prevroot);
    prevroot->setRight(l);
    
    prevroot->setHeight(prevroot->updateHeight());
    cur->setHeight(cur->updateHeight());
    
    return cur;
}

AVL::Node* AVL::rotateRight(Node *prevroot)
{
   Node *cur = prevroot->getLeft();   
   Node *r = cur->getRight();
   
   cur->setRight(prevroot);
   prevroot->setLeft(r);
   
   prevroot->setHeight(prevroot->updateHeight());
   cur->setHeight(cur->updateHeight());
   
   return cur;
}

//operators

AVL& AVL::operator =(const AVL& avl){
    
   // cout<< this->root->getElement()<<endl;
    
    if(this->root != NULL)
        //cout<< "mphke"<<endl;
        this->root = deleteTree(this->root);
       // cout<< "egine delete"<<endl;
	
	
    
    
	this->Create_new_tree(avl.root);
	return *this;
}
    
AVL AVL::operator +(const AVL& avl){
    AVL *ftree = new AVL();
 
    if(this->root != NULL){
        ftree->Create_new_tree(this->root);
    }
    
    if(avl.root !=NULL){
		ftree->Create_new_tree(avl.root);
    }
    return *ftree;
}

AVL& AVL::operator +=(const AVL& avl){
   if(avl.root !=NULL){
       this->Create_new_tree(avl.root);//,root);
}
    return *this;
}

AVL& AVL::operator +=(const string& e){
    
    this->add(e);
    
    return *this;
    
}

AVL& AVL::operator -=(const string& e){
    
    this->rmv(e);
    
    return *this;
    
}

AVL AVL::operator  +(const string& e){
    AVL *ftree;
    
    if(this->root != NULL){
        ftree = new AVL();
        ftree->Create_new_tree(this->root);
        ftree->add(e);
        
    }
    else{
        ftree = new AVL();
        ftree->add(e);
    }
    
    return *ftree;
    
}

AVL AVL::operator  -(const string& e){
       AVL *ftree;
    
    if(this->root != NULL){
        ftree = new AVL();
        ftree->Create_new_tree(this->root);
        ftree->rmv(e);
        
    }
    else{
        ftree = new AVL();
    }
    
    return *ftree;
    
}

//iterator

AVL::Iterator::Iterator(Node *node){
	this->curr_node = node;
	
	if(curr_node != NULL){
		stacnd.push(curr_node);
	}
}

bool AVL::Iterator::hasNext(){
	if(stacnd.empty() == false){
		return true;
	}
	else 
		return false;
	
}


AVL::Node *AVL::Iterator::getNext(){
    Node* next_node;
    
    if(this->hasNext()){
        next_node = stacnd.top();
        stacnd.pop();
        
        if(next_node->getRight() != NULL){
            stacnd.push(next_node->getRight());
        }
        if(next_node->getLeft() != NULL){
            stacnd.push(next_node->getLeft());
        }
        
        
        
        return next_node;
    }
    
    return NULL;
}

AVL::Iterator& AVL::Iterator::operator++(){
    if(this->hasNext()){
        curr_node = this->getNext();
    }
    else{
        curr_node = NULL;
    }
    
    return *this;
}

AVL::Iterator AVL::Iterator::operator++(int a){
    Iterator *new_iter;
    new_iter = new Iterator(this->curr_node);
    
    if(this->hasNext()){
        curr_node = this->getNext();
    }
    else{
        curr_node = NULL;
    }
    
    
    return *new_iter;
}

string AVL:: Iterator::operator*(){

    return this->curr_node->getElement();
}

bool AVL::Iterator::operator!=(Iterator it){
    if(this->curr_node != it.curr_node){
        return true;
    }
    else{
        return false;
    }
}

bool AVL::Iterator::operator==(Iterator it){
    if(this->curr_node == it.curr_node){
        return true;
    }
    else{
        return false;
    }
}


AVL::Iterator AVL::begin() const{
	Iterator* it;

	it = new Iterator(root);
    it->operator++();

	return (*it); 
	
	
}

AVL::Iterator AVL::end() const{
	Iterator* it;
	
	
	it = new Iterator(NULL);
	
	
	return(*it);
}


//print

void AVL::print(std::ostream& out, Node *root)const{
    
    if(root !=NULL){
        out << root->getElement() << " ";
        
        if(root->getLeft() !=NULL){
            print(out, root->getLeft());
            
        }
        
        if(root->getRight() !=NULL){
            print(out, root->getRight());
        }
    }
    
}

void AVL::pre_order(std::ostream& out){
    print(out, root);
}

std::ostream& operator<<(std::ostream& out, const AVL& tree){
    tree.print(out,tree.root);
    return out;
}

string AVL::Node::hashCode(){
	int hash;
	
	
    std::hash<std::string> str_hash;
	hash = str_hash(this->getElement());
	if(this->getParent()!=NULL)
		hash = str_hash(this->getElement() + this->getParent()->getElement());
	
	return(to_string(hash));
	
}
