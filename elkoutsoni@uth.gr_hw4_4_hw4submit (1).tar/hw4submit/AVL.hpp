#ifndef __AVL_HPP_
#define __AVL_HPP_

#include <iostream>
#include <fstream>
#include <stack>

using namespace std;

class AVL {
    private:
    class Node {
        Node *parent, *left, *right;
        int height;
        string element;

  public:
    Node(const string& e, Node *parent, Node *left, Node *right);
    
    Node*  getParent() const;
    Node*  getLeft() const;
    Node*  getRight() const;
    string getElement() const;
    int    getHeight() const;
  
    void setLeft(Node *);
    void setRight(Node *);
    void setParent(Node *);
    void setElement(string e);
    bool isLeft() const;
    bool isRight() const;
    int  rightChildHeight() const;
    int  leftChildHeight() const;
    int  updateHeight();
    bool isBalanced();
    int  Balance(Node *node);
    void setHeight(int num);
    string hashCode();
    


  };
private:
  
  int   size;
  Node* root;
  
  
public:
    
    class Iterator {
  
    private:
        
        stack <Node *> stacnd;
        Node* curr_node;
        
    public:
      Iterator& operator++();
      Iterator operator++(int a);
      string operator*(); 
      bool operator!=(Iterator it);
      bool operator==(Iterator it);
      Node *getNext();
      bool hasNext();
      Iterator(Node *nd); //constructor
    };
    
  Iterator begin() const;  
  Iterator end() const;
  
  static const int MAX_HEIGHT_DIFF = 1;
  AVL();
  AVL(AVL& );
  bool contains(string e);
  bool add(string e);
  bool rmv(string e);
  void print2DotFile(char *filename);
  void pre_order(std::ostream& out);
  bool search(Node *, string str);
  Node *chechforposition(string data);
  Node *rightRotate(Node* n);
  Node *rotateLeft(Node *n);
  Node *rotateRight(Node *n);
  bool hasRight(Node *nd);
  bool hasLeft(Node *nd);
  bool isRoot(Node *nd);
  Node *rmvnode(string e, Node* node, Node** result);
  Node *add_node(Node *nd);
  void print(std::ostream& out, Node *nd)const;
  Node *add_node(Node *nd, string str);
  Node* CreateNode(string data);
  Node* thelastleft(Node *nd);
  Node *rmv_node(Node *root, string value);
  int balance_res(Node *nd);
  int diff(Node *nd);
  void Create_new_tree(Node* treeNode);//, Node* myNode);
  Node *Root();
  string toDotString(Node* node);
  AVL makeTreerec(Node* node, AVL* myTree);
  Node * deleteTree(Node *nd);
  void addTree(Node *nd);


  
  friend std::ostream& operator<<(std::ostream& out, const AVL& tree);  
  AVL& operator  =(const AVL& avl);
  AVL  operator  +(const AVL& avl);
  AVL& operator +=(const AVL& avl);
  AVL& operator +=(const string& e);
  AVL& operator -=(const string& e);
  AVL  operator  +(const string& e);
  AVL  operator  -(const string& e);
};

#endif
