/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw2;

/**
 *
 * @author kouel
 */
public interface Image {
    public void grayscale();
    public void doublesize();
    public void halfsize();
    public void rotateClockwise();
}
