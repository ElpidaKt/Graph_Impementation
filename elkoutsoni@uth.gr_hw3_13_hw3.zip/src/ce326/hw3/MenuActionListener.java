/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;  
import java.io.IOException;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
//import org.apache.commons.io.FileUtils;
import java.nio.file.Files;

import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
/**
 *
 * @author kouel
 */
class MenuActionListener implements ActionListener {
    Ce326Hw3 obj;
    String p_path;
    Path paste_file_path,file_to_copy_path;
    
    public MenuActionListener(Ce326Hw3 hw3) {
        obj = hw3;
    }
    
    public void actionPerformed(ActionEvent e) {
        File file_to_copy, paste_file, file_to_cut, file_to_rename, file_to_delete,favourite_file;
        long length;
        System.out.println("Selected: " + e.getActionCommand());    
        
        if(e.getActionCommand() == "Cut"){
            obj.setCut(1);
            obj.setPaste(0);
            obj.setCopy(0);
            obj.cut_path = obj.filepath;
            System.out.println(obj.cut_path);

        }
        
        if(e.getActionCommand() == "Copy"){
            obj.setPaste(0);
            obj.setCopy(1);
            obj.copy_path = obj.filepath;
            System.out.println(obj.copy_path);
        }
        
        if(e.getActionCommand() == "Paste"){
            obj.setPaste(1);
            
            try{
                System.out.println("paste: "+obj.paste);
                if(obj.copy == 1 && obj.cut == 0){                  // copy paste
                    if (obj.prev!=null){
                        file_to_copy = new File(obj.copy_path + "\\"+ obj.prev.getText());
                        String file_to_copy_str = obj.copy_path + "\\"+ obj.prev.getText();
                        file_to_copy_path = Paths.get(file_to_copy_str);
                    }
                    else{
                        file_to_copy = new File(obj.filepath );
                        String file_to_copy_str = obj.filepath ;
                        file_to_copy_path = Paths.get(file_to_copy_str);
                    }
                    if (obj.b!=null){
                        paste_file = new File(obj.filepath + "\\"+  obj.b.getText() + "\\" + obj.prev.getText());
                        String paste_file_str = obj.filepath + "\\"+  obj.b.getText() + "\\" + obj.prev.getText();
                        paste_file_path = Paths.get(paste_file_str);
                    }
                    else{
                        paste_file = new File(obj.filepath + "\\" + obj.prev.getText() + "\\");
                        String paste_file_str = obj.filepath + "\\" + obj.prev.getText() + "\\";
                        paste_file_path = Paths.get(paste_file_str);
                    }
                    
                    System.out.println("file to copy:"+file_to_copy+"  file to paste"+paste_file + " flag_dir: " + file_to_copy.isDirectory()  );
                    if (obj.prev!=null && obj.b!=null)
                        System.out.println("b: "+obj.b.getText()+" prev: "+obj.prev.getText());
                    if(file_to_copy.isDirectory() == true){
                        obj.copyDirectory(file_to_copy_path, paste_file_path);
                    }
                    else{
                        //obj.CopyPaste(file_to_copy, paste_file);
                        obj.copyDirectory(file_to_copy_path, paste_file_path);

                    }
                    
                    
                    obj.directoryPath = new File(obj.filepath);
                    obj.contents = obj.directoryPath.list();
                    try{
                        obj.Display();

                    }
                    catch(Exception er)  
                    {  
                        er.printStackTrace();  
                    }  
                    obj.rightPanel.repaint();
                    obj.rightPanel.revalidate();
                    
                }
                else if(obj.cut == 1 && obj.copy == 0){            // cut paste
                    System.out.println("egine to cut 111");
                        if (obj.prev!=null){
                            file_to_cut = new File(obj.cut_path + "\\"+ obj.prev.getText());
                        }
                        else{
                            file_to_cut = new File(obj.filepath );
                        }
                        if (obj.b!=null){
                            paste_file = new File(obj.filepath + "\\"+  obj.b.getText() + "\\" + obj.prev.getText());
                        }
                        else{
                            paste_file = new File(obj.filepath + "\\" + obj.prev.getText());
                        }

                        System.out.println("file to cut:"+file_to_cut+"    file to paste"+paste_file  );
                        obj.CutPaste(file_to_cut, paste_file);

                        obj.directoryPath = new File(obj.filepath);
                        obj.contents = obj.directoryPath.list();
                        try{
                            obj.Display();

                        }
                        catch(Exception er)  
                        {  
                            er.printStackTrace();  
                        }  
                        obj.rightPanel.repaint();
                        obj.rightPanel.revalidate();

                    }
                
            }
            catch(IOException er){
                er.printStackTrace();
            }
            
            
            obj.setCopy(0);
            obj.setCut(0);
            
        }
        
        if(e.getActionCommand() == "Rename"){
            obj.setRename(1);
            System.out.println("TRY RENAME");
            file_to_rename = new File(obj.filepath+ "\\"+ obj.prev.getText());
            
            JDialog rename_option = new JDialog(obj.f, "Rename");
            
            JTextField pathname = new JTextField(obj.filepath+ "\\"+ obj.prev.getText());
            
            rename_option.add(pathname, BorderLayout.NORTH);
            pathname.setEditable(true);
            pathname.setVisible(true);
            
            JButton button = new JButton("Done");
            rename_option.add(button, BorderLayout.SOUTH);
            button.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){  
                    File newfile = new File(pathname.getText());
                    file_to_rename.renameTo(newfile);
                    rename_option.dispose();
                    obj.directoryPath = new File(obj.filepath);
                    obj.contents = obj.directoryPath.list();
                    try{
                        obj.Display();

                    }
                    catch(Exception er)  
                    {  
                        er.printStackTrace();  
                    }  
                    obj.rightPanel.repaint();
                    obj.rightPanel.revalidate();
                    
                    
                }  
            });  

            rename_option.setSize(300, 300);
            rename_option.setVisible(true);
        }  
        
        if(e.getActionCommand() == "Delete"){
            obj.setDelete(1);
            obj.delete_path = obj.filepath;
            file_to_delete = new File(obj.delete_path + "\\"+ obj.prev.getText());
            Path path = Paths.get(obj.delete_path + "\\"+ obj.prev.getText());
            System.out.println("file to delete" + path);
            
            JDialog delete_option = new JDialog(obj.f, "Delete");
            JTextField confirmation = new JTextField("Are you sure you want to delete this file?");
            confirmation.setEditable(false);
            JButton yes = new JButton("Yes");
            JButton no = new JButton("No");
            delete_option.add(confirmation, BorderLayout.NORTH);
            delete_option.add(yes, BorderLayout.WEST);
            delete_option.add(no, BorderLayout.EAST);
            
            no.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){ 
                    delete_option.dispose();
                }
            });
                
            yes.addActionListener(new ActionListener(){  
                public void actionPerformed(ActionEvent e){ 
                    delete_option.dispose();
                    if(obj.delete == 1){
                        try{
                            if(file_to_delete.isDirectory()==true){
                                
                                for(File fileEntry : file_to_delete.listFiles()) {
                                    Files.delete(Paths.get(fileEntry.getPath()));
                                    if(fileEntry.exists()){
                                        JDialog delete_not_succeed = new JDialog(obj.f, "Didn't succeed");
                                        JTextField delete_not = new JTextField("Failed to delete the file: " + fileEntry.getName());
                                        delete_not.setEditable(false);
                                        JButton ok = new JButton("OK");
                                        delete_not_succeed.add(delete_not, BorderLayout.NORTH);
                                        delete_not_succeed.add(ok, BorderLayout.SOUTH);
                                        ok.addActionListener(new ActionListener(){  
                                            public void actionPerformed(ActionEvent e){ 
                                                delete_not_succeed.dispose();
                                            }
                                        });
                                        delete_not_succeed.setSize(250, 250);
                                        delete_not_succeed.setVisible(true);
                                    }
                                }
                                Files.delete(path);
                            }
                            else {
                                Files.delete(path);
                                if (file_to_delete.exists() == true){
                                    JDialog delete_not_succeed = new JDialog(obj.f, "Didn't succeed");
                                    JTextField delete_not = new JTextField("Failed to delete the file");
                                    delete_not.setEditable(false);
                                    JButton ok = new JButton("OK");
                                    delete_not_succeed.add(delete_not, BorderLayout.NORTH);
                                    delete_not_succeed.add(ok, BorderLayout.SOUTH);
                                    ok.addActionListener(new ActionListener(){  
                                        public void actionPerformed(ActionEvent e){ 
                                            delete_not_succeed.dispose();
                                        }
                                    });
                                    delete_not_succeed.setSize(250, 250);
                                    delete_not_succeed.setVisible(true);
                                }
                            }
                        }
                        catch(Exception v){
                            v.printStackTrace();
                        }
                        obj.directoryPath = new File(obj.filepath);
                        obj.contents = obj.directoryPath.list();
                        try{
                            obj.Display();

                        }
                        catch(Exception er)  
                        {  
                            er.printStackTrace();  
                        }  
                        obj.rightPanel.repaint();
                        obj.rightPanel.revalidate();
                        
                }
                    }

                });
                        delete_option.setSize(250, 250);
                        delete_option.setVisible(true);

                
        }
        
        if(e.getActionCommand() == "Add to Favourites"){
            
            if (obj.b==null){
                obj.setAdd_to_Favourites(1);
                favourite_file = new File(obj.filepath );
                p_path = obj.filepath ;
            }
            else {
                favourite_file = new File(obj.filepath + "\\"+  obj.b.getText() );
                p_path = obj.filepath + "\\"+  obj.b.getText() ;
            }
            
            if (favourite_file.isDirectory()){
                System.out.println("favourite file: "+favourite_file);
                obj.setAdd_to_Favourites(1);
                // set to xml builder
                this.setXML(favourite_file.getName(), p_path);                
            }

        }  
        
        if(e.getActionCommand() == "Properties"){
            length = 0 ;
            obj.setProperties(1);
            JDialog properties_option = new JDialog(obj.f, "Properties");
            File f = new File(obj.filepath+ "\\"+ obj.prev.getText());
            if (f.isFile()){
                length = f.length();
            }
            else if(f.isDirectory()){
                length = folderSize(f);
                
            }
            
            String[] p_columns = {"Information"};
            Object[][] proper_obj = new Object[3][2];
            Path path = Paths.get(obj.filepath + "\\"+ obj.prev.getText());
            
            JTextField name = new JTextField("Name: " + f.getName());
            JTextField pathname = new JTextField("Path: " + path);
            JTextField size = new JTextField("Size: " + length + " bytes");
            
            
            properties_option.add(name, BorderLayout.NORTH);
            properties_option.add(pathname, BorderLayout.CENTER);
            properties_option.add(size,BorderLayout.SOUTH);
            pathname.setEditable(false);
            name.setEditable(false);
            size.setEditable(false);
            pathname.setVisible(true);
            name.setVisible(true);
            size.setVisible(true);
            
            properties_option.setSize(400, 100);
            properties_option.setVisible(true);
            
        
        }  
    }
    public long folderSize(File directory) {
        long length = 0;
        for (File file : directory.listFiles()) {
            if (file.isFile())
                length += file.length();
            else
                length += folderSize(file);
        }
        return length;
    }
    
    public void setXML(String name, String path){
        String temp_string = obj.xml_builder.toString();
        int index = temp_string.length() - 13;
        String new_xml_string ;
        
        new_xml_string = temp_string.substring(0,index) + "\t<directory name=\""+name+"\" path=\""+path+"\"/>\n"+ temp_string.substring(index,temp_string.length());
        
        System.out.println(new_xml_string);
        
        obj.xml_builder = new StringBuilder(new_xml_string);
        
        try {
            FileWriter myWriter = new FileWriter(obj.properties_file+"\\properties.xml");
            myWriter.write(obj.xml_builder.toString());
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
          } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }
        obj.readXML();
    }
}
