/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw3;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;
/**
 *
 * @author kouel
 */
public class FileSearch {
    Ce326Hw3 obj;
    String NameSearch;
    List<String> result = new ArrayList<String>();
    
    public FileSearch(Ce326Hw3 obj){
        this.obj = obj;
    }
    public String getNameSearch() {
        return NameSearch;
      }

    public void setNameSearch(String Name) {
      this.NameSearch = Name.toLowerCase();
    }

    public List<String> getResult() {
      return result;
    }

  public void searchDirectory(File dir, String NameSearch) {

    setNameSearch(NameSearch);

    if (dir.isDirectory()) {
        searchFile(dir);
    } else {
        System.out.println(dir.getAbsoluteFile() + " is not a directory!");
    }
    //choices();
  }

  private void searchFile(File file) {
    int i;
    
    if (file.isDirectory()) {

        if (file.canRead()) {
            for (File cur : file.listFiles()) {
                if (cur.isDirectory()) {
                    if (cur.getName().toLowerCase().contains(getNameSearch())) {			
                        result.add(cur.getAbsoluteFile().toString());
                        System.out.println("result is: " +result);
                    }
                    searchFile(cur);
                } 
                else {
                    if (cur.getName().toLowerCase().contains(getNameSearch())) {			
                        result.add(cur.getAbsoluteFile().toString());
                        System.out.println("result is: " +result);
                    }
                }   
            }
        } 
        else {
            System.out.println(file.getAbsoluteFile() + "Permission Denied");
        }
      }
    }
  
    public void choices(){
        JDialog options = new JDialog(obj.f, "options");
        //JMenu
        options.setLayout(new BorderLayout()); 
        
        for(String nam : result){
            JTextArea pathname = new JTextArea(nam);
            System.out.println("results: "+nam);
            //JMenuItem pathname = new JMenuItem(nam);
            pathname.setVisible(true);
            
            //pathname.addMouseListener(mouseListener);
            //pathname.setVerticalTextPosition(SwingConstants.BOTTOM);
            //pathname.setHorizontalTextPosition(SwingConstants.CENTER);
            pathname.setOpaque(false);
            //pathname.setContentAreaFilled(false);
            //pathname.setBorderPainted(true);
            //pathname.setToolTipText(contents[i]);
            
            
            options.add(pathname);
        }
        options.setSize(300, 300);
        options.setVisible(true);
    }
}
