/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw3;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.awt.Container;
import java.awt.event.ActionEvent;
import javax.swing.JApplet;
import java.io.IOException;
import java.io.*; 
import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.DocumentBuilder;  
import org.w3c.dom.Document;  
import org.w3c.dom.NodeList;  
import org.w3c.dom.Node;  
import org.w3c.dom.Element;  
import java.io.File;  

import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

//package com.journaldev.xml;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
/**
 *
 * @author kouel
 */
@SuppressWarnings("serial")
public class JFavPopupMenu extends JFrame {
    private JPopupMenu pop;
    Ce326Hw3 obj;
    int row;
    String pathtext;
    
    public JFavPopupMenu(int p_row, String p_pathtext , Ce326Hw3 hw3)  {
        JMenuItem pop_delete;
        this.row = p_row;
        this.pathtext = p_pathtext;
        obj = hw3;
        
        Container contentPane = getContentPane();
        pop = new JPopupMenu();

        pop_delete = new JMenuItem("Delete");
        pop_delete.addActionListener(new MenuActionListener(hw3){
            public void actionPerformed(ActionEvent e) {
                if(e.getActionCommand() == "Delete"){
                    System.out.println("Deleteeee");
                    deleteItemXML(row,pathtext);
                }
            }
        
        });

        /*
       if (copy == 1 && nobutton == 0){
           System.out.println("mphke");
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(true);
           System.out.println("bghke");
       }
       else if(copy == 0 && nobutton == 0){
           pop_paste.setEnabled(false);
       }
       else if(copy == 1 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
       }
       else if(copy == 0 && cut ==0 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(false);
       }
       
       if (cut == 1 && nobutton == 0){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(true);
       }
       else if(cut == 0 && nobutton == 0 && copy != 1){
           pop_paste.setEnabled(false);
       }
       else if(cut == 1 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
       }
       else if(cut == 0 && copy == 0 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(false);
       }
       
       pop.add(pop_cut);
       pop.add(pop_copy);
       pop.add(pop_paste);
       pop.add(pop_rename);
       pop.add(pop_delete);
       pop.add(pop_add_to_favourites);
       pop.add(pop_properties);
       pop.addSeparator();
*/
        pop.add(pop_delete);
        contentPane.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent ev) {
             showPopup(ev);
          }
        }) ;
        pop.setSize(375, 250);
        pop.setVisible(true);
    }
    void showPopup(MouseEvent ev) {

        pop.show(ev.getComponent(), ev.getX(), ev.getY());
        System.out.println(ev.getX() + ev.getY());

    }
    
    void deleteItemXML(int row, String pathtext){
        //File file = new File(System.getProperty("user.home") + "\\Desktop\\test\\" +"\\.java-file-browser\\properties.xml" ); 
        File file = new File(System.getProperty("user.home") +"\\.java-file-browser\\properties.xml" );
        //an instance of factory that gives a document builder  
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            //an instance of builder to parse the specified xml file  
            DocumentBuilder db = dbf.newDocumentBuilder();  

            Document doc = db.parse(file); 

            doc.getDocumentElement().normalize();  
            System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
            NodeList nodeList = doc.getElementsByTagName("directory"); 
            
            Element element = (Element)nodeList.item(row);
            System.out.println("delete element: " + element);
            //        Remove the node
            element.getParentNode().removeChild(element);
            //        Normalize the DOM tree to combine all adjacent nodes
            doc.normalize();
            System.out.println("deleted doc: " + doc);
            
            
            doc.getDocumentElement().normalize(); 
            String newXmlStr = convertDocumentToString(doc);
            
            System.out.println("newXmlStr : " + newXmlStr);
            
            obj.properties_xml = newXmlStr;
            obj.xml_builder = new StringBuilder(newXmlStr);
            
            try {
                FileWriter myWriter = new FileWriter(obj.properties_file+"\\properties.xml");
                myWriter.write(obj.xml_builder.toString());
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
              } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
              }
            
            obj.readXML();
            /*
            System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
            NodeList nodeList2 = doc.getElementsByTagName("directory"); 
            
            obj.favourite_rows = new Object[nodeList2.getLength()][2];
            
            // nodeList is not iterable, so we are using for loop  
            for (int itr = 0; itr < nodeList2.getLength(); itr++)   
            {  
                Node nNode = nodeList2.item(itr);  
                //System.out.println("\nNode Name :" + nNode.getNodeName());  
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("Student roll no : " 
                       + eElement.getAttribute("name"));
                    obj.favourite_rows[itr][0] =  eElement.getAttribute("name");
                    obj.favourite_rows[itr][1] = eElement.getAttribute("path");
                }
            }*/
            /*obj.favourite_rows = new Object[nodeList.getLength()][2];
            
            // nodeList is not iterable, so we are using for loop  
            for (int itr = 0; itr < nodeList.getLength(); itr++)   
            {  
                Node nNode = nodeList.item(itr);  
                //System.out.println("\nNode Name :" + nNode.getNodeName());  
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("Student roll no : " 
                       + eElement.getAttribute("name"));
                    obj.favourite_rows[itr][0] =  eElement.getAttribute("name");
                    obj.favourite_rows[itr][1] = eElement.getAttribute("path");
                }
            }*/
        }catch(ParserConfigurationException  | SAXException | IOException err){
            
        }
    }
    private static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        
        return null;
    }
}
