/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw3;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.awt.Container;
import java.awt.event.ActionEvent;
import javax.swing.JApplet;
import java.io.IOException;
/**
 *
 * @author kouel
 */
@SuppressWarnings("serial")
public class JPopupMenut extends JFrame {
    private JPopupMenu pop;
    
    public JPopupMenut(int copy, int cut, int nobutton, Ce326Hw3 hw3)  {
        JMenuItem pop_cut, pop_copy, pop_paste, pop_rename, pop_delete, pop_add_to_favourites, pop_properties;

        Container contentPane = getContentPane();
        pop = new JPopupMenu();

        pop_cut = new JMenuItem("Cut");
        pop_cut.addActionListener(new MenuActionListener(hw3));

        pop_copy = new JMenuItem("Copy"); 
        pop_copy.addActionListener(new MenuActionListener(hw3));

        pop_paste = new JMenuItem("Paste");
        pop_paste.addActionListener(new MenuActionListener(hw3));

        pop_rename = new JMenuItem("Rename");
        pop_rename.addActionListener(new MenuActionListener(hw3));

        pop_delete = new JMenuItem("Delete");
        pop_delete.addActionListener(new MenuActionListener(hw3));

        pop_add_to_favourites = new JMenuItem("Add to Favourites"); 
        pop_add_to_favourites.addActionListener(new MenuActionListener(hw3));

        pop_properties = new JMenuItem("Properties");
        pop_properties.addActionListener(new MenuActionListener(hw3));

        pop_paste.setEnabled(true);
       if (copy == 1 && nobutton == 0){
           System.out.println("mphke");
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(true);
           System.out.println("bghke");
       }
       else if(copy == 0 && nobutton == 0){
           pop_paste.setEnabled(false);
       }
       else if(copy == 1 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
       }
       else if(copy == 0 && cut ==0 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(false);
       }
       
       if (cut == 1 && nobutton == 0){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(true);
       }
       else if(cut == 0 && nobutton == 0 && copy != 1){
           pop_paste.setEnabled(false);
       }
       else if(cut == 1 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
       }
       else if(cut == 0 && copy == 0 && nobutton == 1){
           pop_cut.setEnabled(false);
           pop_copy.setEnabled(false);
           pop_paste.setEnabled(false);
       }
       
       pop.add(pop_cut);
       pop.add(pop_copy);
       pop.add(pop_paste);
       pop.add(pop_rename);
       pop.add(pop_delete);
       pop.add(pop_add_to_favourites);
       pop.add(pop_properties);
       pop.addSeparator();

       contentPane.addMouseListener(new MouseAdapter() {
          public void mouseReleased(MouseEvent ev) {
             showPopup(ev);
          }
       }) ;
       pop.setSize(375, 250);
       pop.setVisible(true);
    }
    void showPopup(MouseEvent ev) {

        pop.show(ev.getComponent(), ev.getX(), ev.getY());
        System.out.println(ev.getX() + ev.getY());

    }
}
