/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw3;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
/**
 *
 * @author kouel
 */
@SuppressWarnings("serial")
class JTableButtonModel extends AbstractTableModel {
   private Object[][] rows;
   private String[] columns = {"Icon"};
   
   public JTableButtonModel(Object[][] p_rows, String[] p_columns ){
        this.rows = p_rows;
        this.columns = p_columns;
   }
   public JTableButtonModel(Object[][] p_rows){
        this.rows = p_rows;
   }
   public JTableButtonModel(){
        
   }
   
   public String getColumnName(int column) {
      return columns[column];
   }
   public void setRows(Object[][] p_rows){
       this.rows = p_rows;
   }
   public Object[][] getRows(){
       return this.rows;
   }
   public int getRowCount(){
      return rows.length;
   }
   public int getColumnCount() {
      return columns.length;
   }
   public Object getValueAt(int row, int column) {
        /*switch (column) {
            case 1: return rows[row][column];
            case 0: final JButton button = new JButton();
                    button.addMouseListener(new MouseAdapter() {
                        public void mouseClicked(MouseEvent mouseEvent ){
                            
                            System.out.println("Button clicked for row "+row);
                        }
                    });
                    return button;
            default: return rows[row][column];
        }*/

       
       
      return rows[row][column];
   }
   public boolean isCellEditable(int row, int column) {
      return false;
   }
   
   public Class<?> getColumnClass(int column) {
      return getValueAt(0, column).getClass();
   }
}
