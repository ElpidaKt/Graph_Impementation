/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ce326.hw3;

import java.awt.Desktop;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.regex.Pattern;
import java.util.Scanner;
import javax.swing.filechooser.*;
import java.io.File;  
import java.io.FileNotFoundException;  
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner; 
import javax.imageio.ImageIO;
import java.awt.image.*;
import java.io.*;
import java.util.ArrayList;
import javax.imageio.*;
import java.util.Arrays;
import java.util.Collections;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import javax.swing.border.LineBorder;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption.*;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static java.nio.file.FileVisitResult.*;
import java.io.PrintStream;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.lang.Object;
//import org.apache.commons.io.FileUtils;
import java.nio.file.Files;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.DocumentBuilder;  
import org.w3c.dom.Document;  
import org.w3c.dom.NodeList;  
import org.w3c.dom.Node;  
import org.w3c.dom.Element;  
import java.io.File;  

import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import java.nio.file.StandardCopyOption;

import java.nio.file.StandardCopyOption;
import java.util.stream.*;
/**
 *
 * @author kouel
 */
@SuppressWarnings("serial")
public class Ce326Hw3 extends JFrame implements ActionListener{

    JMenuBar mb;
    JSplitPane splitPane;
    JSplitPane splitPane2;
    JSplitPane splitPane3;
    JPanel leftPanel;
    JTextField upper;
    JPanel down;
    JPanel rightPanel;
    JTextField path;
    JLabel statusLabel;
    File file;
    JPanel upper_panel;
    JButton button;
    JButton icon_button;
    JMenu fil, edit, view;
    JMenuItem m1, m2, d1, d2, d3, d4, d5, d6, d7, s2;
    JCheckBoxMenuItem s1;
    JFrame f;
    File directoryPath;
    Ce326Hw3 m;
    String[] contents;
    JTextArea log;
    String newfilepath;
    File[] insideFiles;
    String Input;
    String filepath;
    int returnvalue = 0;
    JButton b = null;
    JButton prev = null;
    JPopupMenut popupmenu;
    int copy, paste, cut, rename, delete, Add_to_Favourites, properties, hidden;
    String copy_path, cut_path, delete_path;
    int flag_dir;
    String[] folders;
    String[] files; 
    JTable  table, favourite_table;
    Object [][] rows;
    JTree tree;
    File properties_file;
    String properties_xml;
    StringBuilder xml_builder;
    Object[][] favourite_rows=null;
    int flag_equals;
    
    public Ce326Hw3() throws IOException{
        xml_builder = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<favourites>\n\t<directory name=\"Home\" path=\""+System.getProperty("user.home")+"\"/>\n</favourites>");
        
        
        f = new JFrame();
        //f.addMouseListener();
        mb = new JMenuBar();
        //filepath = System.getProperty("user.home") + "\\Desktop\\test";
        filepath = System.getProperty("user.home");
        newfilepath = filepath.replaceAll("\\\\",">");
        icon_button = new JButton("Init");
        statusLabel = new JLabel("",JLabel.CENTER);        
        statusLabel.setSize(350,100);
        
        f.add(statusLabel);
        menubar();
        contents = Filepath();
        System.out.println(newfilepath);
        log = new JTextArea(5,20);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(true);
        
        Panelsimplementation();
        
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(500, 500);
        f.setVisible(true);
        
        this.copy=0;
        this.paste=0;
        this.cut=0;
        this.rename=0;
        this.delete=0;
        this.Add_to_Favourites=0;
        this.properties=0;
        this.copy_path="";
        this.cut_path="";
        this.delete_path ="";
        this.m=Ce326Hw3.this;
        this.hidden = 0;

        //Creating a File object
        properties_file = new File(filepath+"\\.java-file-browser");
        //Creating the directory
        boolean bool = properties_file.mkdirs();
        if(bool){
            
        }else{
            System.out.println("Already exists java-file-browser directory");
            //return;
        }
        System.out.println("java-file-browser created successfully => \n"+xml_builder.toString());
        
        try {
            FileWriter myWriter = new FileWriter(properties_file+"\\properties.xml");
            myWriter.write(xml_builder.toString());
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
          } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }
        
        readXML();
        
        
    }
    
    public void readXML() {
        leftPanel.removeAll();
        //creating a constructor of file class and parsing an XML file  
        //File file = new File(System.getProperty("user.home") + "\\Desktop\\test\\" +"\\.java-file-browser\\properties.xml" );  
        File file = new File(System.getProperty("user.home") +"\\.java-file-browser\\properties.xml" );  
        //an instance of factory that gives a document builder  
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            //an instance of builder to parse the specified xml file  
            DocumentBuilder db = dbf.newDocumentBuilder();  

            Document doc = db.parse(file); 

            doc.getDocumentElement().normalize();  
            System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
            NodeList nodeList = doc.getElementsByTagName("directory"); 
            
            favourite_rows = new Object[nodeList.getLength()][2];
            
            // nodeList is not iterable, so we are using for loop  
            for (int itr = 0; itr < nodeList.getLength(); itr++)   
            {  
                Node nNode = nodeList.item(itr);  
                //System.out.println("\nNode Name :" + nNode.getNodeName());  
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("Student roll no : " 
                       + eElement.getAttribute("name"));
                    favourite_rows[itr][0] =  eElement.getAttribute("name");
                    favourite_rows[itr][1] = eElement.getAttribute("path");
                }
            }
        }catch(ParserConfigurationException  | SAXException | IOException err){
            
        }
        
        MouseListener mouseListener2 = new MouseAdapter() {
             
                public void mouseClicked(MouseEvent mouseEvent ){
                    Object o = mouseEvent.getSource();
                    flag_dir=0;
                    String buttonText = "", pathtext;
                    int row;

                    
                    
                    Object source = mouseEvent.getSource();

                    if (mouseEvent.getClickCount() == 1 && (mouseEvent.getButton() == MouseEvent.BUTTON1)) {
                        row = favourite_table.getSelectedRow();
                        pathtext = (String)favourite_rows[row][1];
                        System.out.println("pathtext is: "+pathtext);
                    
                        System.out.println("row: "+row);
                        directoryPath = new File(pathtext);
                        filepath = pathtext;
                        contents = directoryPath.list();
                        path.setText(filepath);
                        try{
                            Display();

                        }
                        catch(Exception e)  
                        {  
                            e.printStackTrace();  
                        }  
                        rightPanel.repaint();
                        rightPanel.revalidate();
                        
                        
                    }else if (mouseEvent.getClickCount() == 1 && (mouseEvent.getButton() == MouseEvent.BUTTON3)) {
                        row = favourite_table.getSelectedRow();
                        System.out.println("row "+row);
                        if (row == -1){
                            System.out.println("Select a row with left click first and then right click\n");
                        }
                        else{
                            pathtext = (String)favourite_rows[row][1];
                            System.out.println("pathtext is: "+pathtext);
                            
                            JFavPopupMenu favpopupmenu = new JFavPopupMenu(row,pathtext,Ce326Hw3.this); 
                            favpopupmenu.showPopup(mouseEvent);
                            
                        }
                        
                    }
                        
                }
            };
        
        
        
        String[] p_columns = {"Favourites"};
                
        TableCellRenderer tableRenderer;
        favourite_table = new JTable(new JTableButtonModel(favourite_rows,p_columns));
        
        //table.getPreferredSize();
        //table.setSize(1, 1);
        
        
        tableRenderer = favourite_table.getDefaultRenderer(JButton.class);
        favourite_table.setDefaultRenderer(JButton.class, new JTableButtonRenderer(tableRenderer));
        JScrollPane scrollPane = new JScrollPane(favourite_table);
        
        Dimension d = scrollPane.getPreferredSize();
        scrollPane.setPreferredSize(new Dimension(150,500));
        
        Scrollbar s=new Scrollbar();  
        s.setBounds(150,20, 10,500);  
        scrollPane.add(s);  
        
        favourite_table.setSize(1, 1);
        leftPanel.add(scrollPane, BorderLayout.CENTER);
        favourite_table.addMouseListener(mouseListener2);
        
        leftPanel.repaint();
        leftPanel.revalidate();
    }
    
    public String[] listFiles(File f){
        String[] pathnames;
        
        pathnames = f.list();
        
         return pathnames;
    }
    
    public void actionPerformed(ActionEvent e) {
        boolean state;
        
        System.out.println("paeiiii");
        if("Exit".equals(e.getActionCommand())){

            int dialogButton = JOptionPane.YES_NO_OPTION;
            JOptionPane.showConfirmDialog (null, "Would You Like to Save your Previous Note First?","Warning",dialogButton);

            if(dialogButton == JOptionPane.YES_OPTION){
               //System.out.exit();
            }
        }
       
        if("Search".equals(e.getActionCommand())){
            if(s1.isSelected() == true){
                upper.setVisible(true);
                button.setVisible(true);
                upper_panel.setVisible(true);
                upper_panel.repaint();
                upper_panel.revalidate();
            }
            else if(s1.isSelected() == false){
                upper_panel.setVisible(false);
            }
        }
    }
    
    
    public String GetFileExtension(String Content)
    {
      int index = Content.lastIndexOf('.');
      if(index > 0) {
        String extension = Content.substring(index + 1);
        return extension;
      }
      return "folder";
    }
    
    public void menubar(){
        int i;
        fil = new JMenu("File");
        edit = new JMenu("Edit");
        view = new JMenu("View");
        
        // create menuitems
        m1 = new JMenuItem("New Window");
        m2 = new JMenuItem("Exit");
        m2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                System.exit(0);
            }});
        
        d1 = new JMenuItem("Cut");
        d1.addActionListener(new MenuActionListener(Ce326Hw3.this));
        
        d2 = new JMenuItem("Copy");
        d2.addActionListener(new MenuActionListener(Ce326Hw3.this));
        
        d3 = new JMenuItem("Paste");
        d3.addActionListener(new MenuActionListener(Ce326Hw3.this));
        
        d4 = new JMenuItem("Rename");
        d4.addActionListener(new MenuActionListener(Ce326Hw3.this));

        d5 = new JMenuItem("Delete");
        d5.addActionListener(new MenuActionListener(Ce326Hw3.this));

        d6 = new JMenuItem("Add to Favourites");
        d6.addActionListener(new MenuActionListener(Ce326Hw3.this));

        d7 = new JMenuItem("Properties");
        d7.addActionListener(new MenuActionListener(Ce326Hw3.this));
        
        button = new JButton("Search");

        s1 = new JCheckBoxMenuItem ("Search");
        s1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                int i, j;
                
                if(s1.isSelected() == true){
                    upper.setVisible(true);
                    button.setVisible(true);
                    upper_panel.setVisible(true);
                    upper_panel.repaint();
                    upper_panel.revalidate();
                    
                    button.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e){
                            int i, k;
                            StringBuilder name = new StringBuilder();
                            String newname, prevname;
                            
                            prevname = upper.getText();
                                    
                            for(i=0; i< prevname.length(); i++){
                                if(prevname.charAt(i) == '.'){
                                    break;
                                }
                                else{
                                    name.append(prevname.charAt(i));
                                }
                            }
                            newname = name.toString();
                            
                            FileSearch fileSearch = new FileSearch(Ce326Hw3.this);
                            fileSearch.searchDirectory(new File(filepath), newname);
                            
                            System.out.println("fileSearch is" +fileSearch.getResult());
                            
                             int count = fileSearch.getResult().size();
                             System.out.println("Count is: " +fileSearch.getResult().size());
                             if(count ==0){
                                System.out.println("\nNo result found!");
                             }
                             else{
                                System.out.println("\nFound " + count + " result!\n");
                             }
                                //List<String> names = new ArrayList<>();
                                //names = 
                                try{
                                    searchDisplay(fileSearch);
                                }
                                catch(Exception er)  
                                {  
                                    er.printStackTrace();  
                                }  
                                
                                    /*directoryPath = new File(matched);
                                    
                                    File dir= new File(directoryPath.getParent());
                                    
                                   
                                    
                                    filepath = directoryPath.getParent();
                                    contents = dir.list();
                                    
                                    
                                    
                                    try{
                                        Display();

                                    }
                                    catch(Exception er)  
                                    {  
                                        er.printStackTrace();  
                                    }  
                                    rightPanel.repaint();
                                    rightPanel.revalidate();*/
                        }
                               
                    });
                           /* StringBuilder name = new StringBuilder();
                            
                            System.out.println("button is clicked");
                            if(upper.getText().contains("dir")){
                                System.out.println("contains dir");
                 
                                for(i=0; i< folders.length; i++){
                                    name = new StringBuilder();
                                    for(k=0;k<folders[i].length();k++){
                                        if(folders[i].charAt(k) == '.'){
                                            break;
                                        }
                                        else{
                                            name.append(folders[i].charAt(k));
                                        }
                                    } */
                                    /*System.out.println("folder is " + name.toString());
                                    System.out.println("Textfield " + upper.getText());
                                    if(name.toString().contains( upper.getText()) == true){
                                        System.out.println("folder is " + name.toString());
                                        Path p = Paths.get(folders[i]);
                                        System.out.println("path is " +p.toString());
                                        directoryPath = new File(filepath + "\\" +p.toString());
                                        File dir= new File(directoryPath.getParent());
                                        contents = dir.list(); */
                                  
                            
                 
                }
                
                else if(s1.isSelected() == false){
                    upper_panel.setVisible(false);
                }

                    
            }
        });
        
        s2 = new JCheckBoxMenuItem("Hidden Files/Folders");
        s2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                
                if(s2.isSelected() == true){
                    hidden = 1;
                    directoryPath = new File(filepath);
                    contents = directoryPath.list();
                    try{
                        Display();

                    }
                    catch(Exception e)  
                    {  
                        e.printStackTrace();  
                    }
                    rightPanel.repaint();
                    rightPanel.revalidate();
                }
                else{
                    hidden = 0;
                    directoryPath = new File(filepath);
                    contents = directoryPath.list();
                    try{
                        Display();

                    }
                    catch(Exception e)  
                    {  
                        e.printStackTrace();  
                    }  
                    rightPanel.repaint();
                    rightPanel.revalidate();
                }
            }
        });
 
   
        // add menu items to menu
        //fil.add(m1);
        fil.add(m2);
        
        edit.add(d1);
        edit.add(d2);
        edit.add(d3);
        edit.add(d4);
        edit.add(d5);
        edit.add(d6);
        edit.add(d7);
        
        view.add(s1);
        view.add(s2);

        mb.add(fil);
        mb.add(edit);
        mb.add(view);
  
        f.setJMenuBar(mb);
    }
    public String UpdateFilePath(String Folder){
        newfilepath = newfilepath + ">" + Folder;

        System.out.println(newfilepath);
        return newfilepath;
    }
    public String[] Filepath(){        
        //String filepath = System.getProperty("user.home") + "\\Desktop\\test";
        String filepath = System.getProperty("user.home");
        System.out.println(filepath);

        newfilepath = filepath.replaceAll("\\\\",">");

        File directoryPath = new File(filepath);
        String contents[] = directoryPath.list();
        
        return contents;
    }
    
    
    public void Panelsimplementation() throws IOException{
        
        leftPanel = new JPanel();
        rightPanel = new JPanel();
        JScrollPane scrollPane = new JScrollPane(rightPanel); 
        leftPanel.setBackground(Color.LIGHT_GRAY);
        rightPanel.setBackground(Color.LIGHT_GRAY);
        path = new JTextField(newfilepath);
        path.setEditable(false);
        
        upper_panel = new JPanel();
        upper = new JTextField();
        upper.setColumns(10);
        upper_panel.add(upper, BorderLayout.WEST);
        upper_panel.add(button, BorderLayout.EAST);
        upper_panel.setVisible(false);
        splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, upper_panel, path);
        
        try{
            Display();
          
        }
        catch(Exception e)  
        {  
            e.printStackTrace();  
        }  
      
        splitPane3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane2,rightPanel);
        rightPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                System.out.println("Pressed");
                if(e.getClickCount() == 1 && (e.getButton() == MouseEvent.BUTTON3)) {
                        System.out.print(filepath+"\n");
                        b=null;
                        popupmenu = new JPopupMenut(copy, cut, 1, Ce326Hw3.this); 
                        popupmenu.showPopup(e);
                }
            }
        });
        
        //spliting horizontal
        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, splitPane3);
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(150);

        Dimension minimumSize = new Dimension(100, 50);
        leftPanel.setMinimumSize(minimumSize);
        rightPanel.setMinimumSize(minimumSize);
       
        f.add(splitPane, BorderLayout.CENTER);
    }
    public void Display() throws IOException{
        BufferedImage image;
        String extension, filename;
        
        System.out.println(newfilepath);
       
        rightPanel.removeAll();
        int i;
        int k = 0;
        int j = 0;
        for(i=0; i<contents.length; i++) {
            extension =  GetFileExtension(contents[i]);
            if(extension == "folder"){
                k++;
            }
            else{
                j++;
            }
        }
       
        folders = new String[k];
        files = new String[j];
        k = 0;
        j = 0;
        
        for(i=0; i<contents.length; i++) {
            extension =  GetFileExtension(contents[i]);
            if(extension == "folder"){ 
                folders[k] = new String(contents[i]); 
                k++;
            }
            else{
                files[j] = new String(contents[i]);
                j++;
            }
        }
        Arrays.sort(files, Collections.reverseOrder());
        System.out.println(Arrays.toString(folders));

        Arrays.sort(folders, Collections.reverseOrder());  
        ArrayList<String> list = new ArrayList<String>(Arrays.asList(files));   
        list.addAll(Arrays.asList(folders));     
        Object[] result = list.toArray();       
        System.out.println(Arrays.toString(result)); 
        
        
        
        for(i=0; i<result.length; i++) {
            
            String Show = contents[i];
            //System.out.println("the cur file is: "+ filepath+ "\\" + Show);
            extension =  GetFileExtension(contents[i]);
            File cur_file = new File(filepath+ "\\" + Show);
            
            if(cur_file.isHidden() && hidden == 0){
                continue;
            }
                
            Input = contents[i];
            switch(extension) 
            {
            case "audio":
                image = ImageIO.read(new File("icons\\audio.png"));
                ImageIcon imageIcon1 = new ImageIcon(image);
                icon_button = new JButton(Show, imageIcon1);

              break;
              
            case "bmp":
                image = ImageIO.read(new File("icons\\bmp.png"));
                ImageIcon imageIcon2 = new ImageIcon(image);
                icon_button = new JButton(Show, imageIcon2);
               
              break;
              
            case "doc":
              image = ImageIO.read(new File("icons\\doc.png"));
              ImageIcon imageIcon3 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon3);
              
            break;
            
            case "docx":
              image = ImageIO.read(new File("icons\\docx.png"));
              ImageIcon imageIcon4 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon4);
             
            break;
              
            case "folder":
              image = ImageIO.read(new File("icons\\folder.png"));
              ImageIcon imageIcon5 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon5);

            break;
            
            case "giff":
              image = ImageIO.read(new File("icons\\giff.png"));
              ImageIcon imageIcon6 = new ImageIcon(image);
              icon_button= new JButton(Show, imageIcon6);
              
            break;
            
            case "gz":
              image = ImageIO.read(new File("icons\\gz.png"));
              ImageIcon imageIcon7 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon7);
              
            break;
            
            case "htm":
              image = ImageIO.read(new File("icons\\htm.png"));
              ImageIcon imageIcon8 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon8);
              
            break;
            
            case "html":
              image = ImageIO.read(new File("icons\\html.png"));
              ImageIcon imageIcon9 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon9);
              
            break;
            
            case "image":
              image = ImageIO.read(new File("icons\\image.png"));
              ImageIcon imageIcon10 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon10);
             
            break;
            
            case "jpeg":
              image = ImageIO.read(new File("icons\\jpeg.png"));
              ImageIcon imageIcon11 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon11);
              
            break;
            
            case "jpg":
              image = ImageIO.read(new File("icons\\jpg.png"));
              ImageIcon imageIcon12 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon12);
              
            break;
            
            case "mp3":
              image = ImageIO.read(new File("icons\\mp3.png"));
              ImageIcon imageIcon13 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon13);
             
            break;
            
            case "ods":
              image = ImageIO.read(new File("icons\\ods.png"));
              ImageIcon imageIcon14 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon14);
             
            break;
            
            case "odt":
              image = ImageIO.read(new File("icons\\odt.png"));
              ImageIcon imageIcon15 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon15);
              
            break;
            
            case "ogg":
              image = ImageIO.read(new File("icons\\ogg.png"));
              ImageIcon imageIcon16 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon16);
              
            break;
            
            case "pdf":
              image = ImageIO.read(new File("icons\\pdf.png"));
              ImageIcon imageIcon17 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon17);
              
            break;
            
            case "png":
              image = ImageIO.read(new File("icons\\png.png"));
              ImageIcon imageIcon18 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon18);
              
            break;
            
            case "question":
              image = ImageIO.read(new File("icons\\question.png"));
              ImageIcon imageIcon19 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon19);
              
            break;
            
            case "tar":
              image = ImageIO.read(new File("icons\\tar.png"));
              ImageIcon imageIcon20 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon20);
              
            break;
            
            case "tgz":
              image = ImageIO.read(new File("icons\\tgz.png"));
              ImageIcon imageIcon21 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon21);
              
            break;
            
            case "txt":
              image = ImageIO.read(new File("icons\\txt.png"));
              ImageIcon imageIcon22 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon22);
              
            break;
            
            case "video":
              image = ImageIO.read(new File("icons\\video.png"));
              ImageIcon imageIcon24 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon24);
            
            break;
            
            case "wav":
              image = ImageIO.read(new File("icons\\wav.png"));
              ImageIcon imageIcon23 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon23);
              
            break;
            
            case "xlsx":
              image = ImageIO.read(new File("icons\\xlsx.png"));
              ImageIcon imageIcon25 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon25);
             
            break;
            
            case "xlx":
              image = ImageIO.read(new File("icons\\xlx.png"));
              ImageIcon imageIcon26 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon26);
              
            break;
            
            case "xml":
              image = ImageIO.read(new File("icons\\xml.png"));
              ImageIcon imageIcon27 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon27);
              
            break;
            
            case "zip":
              image = ImageIO.read(new File("icons\\zip.png"));
              ImageIcon imageIcon28 = new ImageIcon(image);
              icon_button = new JButton(Show, imageIcon28);
              
            break;
            
            default:
              // code block
        }   
            
         
         MouseListener mouseListener = new MouseAdapter() {
             
                public void mouseClicked(MouseEvent mouseEvent ){
                    Object o = mouseEvent.getSource();
                    flag_dir=0;
                    String buttonText = "";

                    if(o instanceof JButton){
                      b = (JButton)o;
                      b.setEnabled(false);
                      if(prev!=null)
                        prev.setEnabled(true);
                    }
                    
                    Object source = mouseEvent.getSource();

                    if(b != null)
                      buttonText = b.getText();
                    System.out.println(buttonText);

                    if (mouseEvent.getClickCount() == 2 && (mouseEvent.getButton() == MouseEvent.BUTTON1)) {
                       // JFileChooser choice = new JFileChooser();
                       
                       System.out.println("listener");
                       File file_to_open = new File(filepath + "\\"+ buttonText);
   
                       if(file_to_open.isDirectory() == true){
                            flag_dir=1;
                            filepath = filepath + "\\"+ buttonText;
                            newfilepath = UpdateFilePath(buttonText);
                            String update =  ">"+ buttonText;
                            path.setText(path.getText() + update); 
                            rightPanel.removeAll();
                            rightPanel.repaint();
                            rightPanel.revalidate();
                            System.out.println("heyy");
                            directoryPath = new File(filepath);
                            contents = directoryPath.list();
                            try{
                                Display();

                            }
                            catch(Exception e)  
                            {  
                                e.printStackTrace();  
                            }  
                        
                        }
                        else{

                            Desktop desktop = Desktop.getDesktop();
                            try{
                                desktop.open(file_to_open);
                            }
                            catch(Exception e)  
                             {  
                             
                             }  
                        }
                    }
                    
                    else if (mouseEvent.getClickCount() == 1 && (mouseEvent.getButton() == MouseEvent.BUTTON1)) {
                        System.out.println("ffffffffffff");
                        File file_to_open = new File(filepath + "\\"+ buttonText);
                        b.setFocusable(true);
                        if(file_to_open.isDirectory() == true)
                            flag_dir=1;

                    }
                    
                    
                    else if(mouseEvent.getClickCount() == 1 && (mouseEvent.getButton() == MouseEvent.BUTTON3)) {
                        System.out.println("aaaaaaaaaaa");
                        File file_to_open = new File(filepath + "\\"+ buttonText);
                        b.setFocusable(true);
                        popupmenu = new JPopupMenut(copy, cut, 0, Ce326Hw3.this); 
                        popupmenu.showPopup(mouseEvent);
                        
                       
                    }
                    if(flag_dir==1){
                        flag_dir=0;
                    }
                    else{
                        prev = b;
                    }
                    
                    
                }
                
            };
         
            icon_button.addMouseListener(mouseListener);
            icon_button.setVerticalTextPosition(SwingConstants.BOTTOM);
            icon_button.setHorizontalTextPosition(SwingConstants.CENTER);
            icon_button.setOpaque(false);
            icon_button.setContentAreaFilled(false);
            icon_button.setBorderPainted(true);
            icon_button.setToolTipText(contents[i]);
            rightPanel.add(icon_button);
            
        }
    }
    
    public void setCopy(int copy){
        this.copy = copy;
       
    }
    public void setPaste(int paste){
        this.paste = paste;
        
    }
    public void setCut(int cut){
        this.cut = cut;
       
    }
    public void setRename(int rename){
        this.rename = rename;
      
    }
    public void setDelete(int delete){
        this.delete = delete;
        
    }
    public void setAdd_to_Favourites(int Add_to_Favourites){
        this.Add_to_Favourites = Add_to_Favourites;
        
    }
    public void setProperties(int properties){
        this.properties = properties;
        
    }
    
    public void CopyPaste(File copypath, File pastepath) throws IOException{
        System.out.println("d"+pastepath.getParentFile().mkdirs());
        Files.copy(copypath.toPath(), pastepath.toPath(), REPLACE_EXISTING);

    }
    
    public void copyDirectory(Path sourceDirectory, Path destinationDirectory) throws IOException {
        /*Files.walk(sourceDirectory)
                .forEach(sourcePath -> {
                    //try {
                    File cop_file = new File(sourcePath.toString());
                     System.out.println("Copy to: "+sourceDirectory);
                        File past_file = new File(destinationDirectory.toString());
                        String parent = past_file.getParent();
                        
                        File target = new File(parent);
                        System.out.println("to: "+target);
                        for(File fileEntry : target.listFiles()) {
                            //System.out.printf("Copying %s to %s%n", sourcePath, targetPath);
                            System.out.println("Copy to: "+cop_file.getName()+ " sto: "+fileEntry.getName());
                            if(cop_file.getName().equals(fileEntry.getName())){
                                System.out.println("mphke giati einai idia");
                                JDialog replace = new JDialog(f, "Permission");

                                JTextField pathname = new JTextField("File "+cop_file.getName() +" already exists!\nWould you like to replace it?");

                                replace.add(pathname, BorderLayout.NORTH);
                                pathname.setEditable(false);
                                pathname.setVisible(true);

                                JButton button_yes = new JButton("Yes");
                                JButton button_no = new JButton("No");
                                replace.add(button_yes, BorderLayout.WEST);
                                replace.add(button_no, BorderLayout.EAST);
                                button_yes.addActionListener(new ActionListener(){  
                                    public void actionPerformed(ActionEvent e){ 
                                        try{
                                         Path destpath = Paths.get(parent);
                                         System.out.println("parent: "+destpath);
                                        Path targetPath = destinationDirectory.resolve(sourceDirectory.relativize(sourcePath));
                                        //String 
                                        System.out.println("targetpath" + targetPath);
                                        Files.copy(sourcePath, destpath, StandardCopyOption.REPLACE_EXISTING);
//Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
                                        }
                                        catch(IOException er){
                                            er.printStackTrace();
                                        }

                                        replace.dispose();

                                    }

                                });
                                button_no.addActionListener(new ActionListener(){  
                                    public void actionPerformed(ActionEvent e){ 
                                        replace.dispose();
                                    }
                                });
                                replace.setSize(300, 300);
                                replace.setVisible(true);

                            }
                    
                        }
                        
                        
                   */ 
                      /*  
                        }catch (IOException ex) {
                        System.out.format("I/O error: %s%n", ex);
                    }
                        */
                //});
        
        // Traverse the file tree and copy each file/directory.
        Files.walk(sourceDirectory)
                .forEach(sourcePath -> {
                    //try {
                    File copy_file = new File(sourcePath.toString());
                    if(sourcePath.equals(sourceDirectory) && copy_file.isDirectory()){
                        
                    }
                    else{
                        Path targetPath = destinationDirectory.resolve(sourceDirectory.relativize(sourcePath));
                        File targetPathFile = new File(targetPath.toString());
                        System.out.println("SOURCE PATH: "+sourcePath);
                        flag_equals = -1;
                        File cop_file = new File(sourcePath.toString());
                        System.out.println("Copy: "+cop_file);
                        File past_file = new File(destinationDirectory.toString());
                        String parent = past_file.getParent();
                        
                        File target = new File(parent);
                        System.out.println("to: "+target);
                        //for(File fileEntry : target.listFiles()) {
//                        if(cop_file.getName().equals(fileEntry.getName())){
                        if(targetPathFile.exists()){
                            flag_equals = 1;
                            System.out.println("mphke giati einai idia"+cop_file.getName());
                            JDialog replace = new JDialog(f, "Permission");

                            JTextField pathname = new JTextField("File "+cop_file.getName() +" already exists!\nWould you like to replace it?");

                            replace.add(pathname, BorderLayout.NORTH);
                            pathname.setEditable(false);
                            pathname.setVisible(true);

                            JButton button_yes = new JButton("Yes");
                            JButton button_no = new JButton("No");
                            replace.add(button_yes, BorderLayout.WEST);
                            replace.add(button_no, BorderLayout.EAST);


                            button_yes.addActionListener(new ActionListener(){  
                                public void actionPerformed(ActionEvent e){ 
                                    try{
                                        //Path targetPath = destinationDirectory.resolve(sourceDirectory.relativize(sourcePath));
                                        System.out.printf("Copying %s to %s%n", sourcePath, targetPath);
                                        copyFolder(sourcePath, targetPath);
                                    }
                                    catch(IOException er){
                                       // er.printStackTrace();
                                    }

                                    replace.dispose();

                                }

                            });
                            button_no.addActionListener(new ActionListener(){  
                                public void actionPerformed(ActionEvent e){ 
                                    replace.dispose();

                                }
                            });
                            replace.setSize(300, 300);
                            replace.setVisible(true);
                        }
                        else{
                            try{
                                //Path targetPath = destinationDirectory.resolve(sourceDirectory.relativize(sourcePath));
                                System.out.printf("Copying %s to %s%n", sourcePath, targetPath);
                                copyFolder(sourcePath, targetPath);
                            }
                            catch(IOException er){
                               // er.printStackTrace();
                            }
                        }
                    }
                        //}
                        /*if(flag_equals == -1){
                            System.out.printf("MPHKE STO FLAG");

                          try{
                                Path targetPath = destinationDirectory.resolve(sourceDirectory.relativize(sourcePath));
                                System.out.printf("Copying %s to %s%n", sourcePath, targetPath);
                                copyFolder(sourcePath, targetPath);
                            }
                            catch(IOException er){
                               // er.printStackTrace();
                            }
                        }
                        else{
                            flag_equals = -1;
                        }*/
                        
                        
                    //} catch (IOException ex) {
                        //System.out.format("I/O error: %s%n", ex);
                    //}
                });
        /*try {
            Files.copy(sourceDirectory, destinationDirectory);
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
    
                        }

    public  void copyFolder(Path src, Path dest) throws IOException {
        try (Stream<Path> stream = Files.walk(src)) {
            stream.forEach(source -> copy(source, dest.resolve(src.relativize(source))));
        }
    }
 
    private void copy(Path source, Path dest) {
        try {
            Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            //throw new RuntimeException(e.getMessage(), e);
        }
    }
    public void CutPaste(File copypath, File pastepath) throws IOException{
        System.out.println("d"+pastepath.getParentFile().mkdirs());
        Files.move(copypath.toPath(), pastepath.toPath(), REPLACE_EXISTING);

    }
    
    public void searchDisplay(FileSearch res)throws IOException{
        rightPanel.removeAll();
        BufferedImage image;
        ImageIcon imageIcon;
        rows = new Object[res.getResult().size()][2];
        int i=0;
        
        
        for (String matched : res.getResult()){
            File file = new File(matched);
            //file.setVerticalTextPosition(SwingConstants.BOTTOM);
            //file.setHorizontalTextPosition(SwingConstants.CENTER);
            String extension =  GetFileExtension(matched);
            
            rows[i][1] = new String(matched);
            
            switch(extension) 
            {
                case "audio":
                    image = ImageIO.read(new File("icons\\audio.png"));
                    ImageIcon imageIcon1 = new ImageIcon(image);
                    Image newimg = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                    imageIcon = new ImageIcon(newimg);  // transform it back
                  
                  
                    icon_button = new JButton(imageIcon);

                  break;

                case "bmp":
                    image = ImageIO.read(new File("icons\\bmp.png"));
                    ImageIcon imageIcon2 = new ImageIcon(image);
                    Image newimg2 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                    imageIcon = new ImageIcon(newimg2);  // transform it back
                  
                  
                    icon_button = new JButton(imageIcon);

                  break;

                case "doc":
                  image = ImageIO.read(new File("icons\\doc.png"));
                  ImageIcon imageIcon3 = new ImageIcon(image);
                  Image newimg3 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg3);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "docx":
                  image = ImageIO.read(new File("icons\\docx.png"));
                  ImageIcon imageIcon4 = new ImageIcon(image);
                  Image newimg4 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg4);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "folder":
                  image = ImageIO.read(new File("icons\\folder.png"));
                  ImageIcon imageIcon5 = new ImageIcon(image);
                  Image newimg5 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg5);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "giff":
                  image = ImageIO.read(new File("icons\\giff.png"));
                  ImageIcon imageIcon6 = new ImageIcon(image);
                  Image newimg6 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg6);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "gz":
                  image = ImageIO.read(new File("icons\\gz.png"));
                  ImageIcon imageIcon7 = new ImageIcon(image);
                  Image newimg7 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg7);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "htm":
                  image = ImageIO.read(new File("icons\\htm.png"));
                  ImageIcon imageIcon8 = new ImageIcon(image);
                  Image newimg8 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg8);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "html":
                  image = ImageIO.read(new File("icons\\html.png"));
                  ImageIcon imageIcon9 = new ImageIcon(image);
                  Image newimg9 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg9);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "image":
                  image = ImageIO.read(new File("icons\\image.png"));
                  ImageIcon imageIcon10 = new ImageIcon(image);
                  Image newimg10 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg10);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "jpeg":
                  image = ImageIO.read(new File("icons\\jpeg.png"));
                  ImageIcon imageIcon11 = new ImageIcon(image);
                  Image newimg11 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg11);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);
                break;

                case "jpg":
                  image = ImageIO.read(new File("icons\\jpg.png"));
                  ImageIcon imageIcon12 = new ImageIcon(image);
                  Image newimg12 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg12);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "mp3":
                  image = ImageIO.read(new File("icons\\mp3.png"));
                  ImageIcon imageIcon13 = new ImageIcon(image);
                  Image newimg13 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg13);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "ods":
                  image = ImageIO.read(new File("icons\\ods.png"));
                  ImageIcon imageIcon14 = new ImageIcon(image);
                  Image newimg14 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg14);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "odt":
                  image = ImageIO.read(new File("icons\\odt.png"));
                  ImageIcon imageIcon15 = new ImageIcon(image);
                  Image newimg15 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg15);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "ogg":
                  image = ImageIO.read(new File("icons\\ogg.png"));
                  ImageIcon imageIcon16 = new ImageIcon(image);
                  Image newimg16 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg16);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "pdf":
                  image = ImageIO.read(new File("icons\\pdf.png"));
                  ImageIcon imageIcon17 = new ImageIcon(image);
                  Image newimg17 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg17);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "png":
                  image = ImageIO.read(new File("icons\\png.png"));
                  ImageIcon imageIcon18 = new ImageIcon(image);
                  Image newimg18 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg18);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "question":
                  image = ImageIO.read(new File("icons\\question.png"));
                  ImageIcon imageIcon19 = new ImageIcon(image);
                  Image newimg19 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg19);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "tar":
                  image = ImageIO.read(new File("icons\\tar.png"));
                  ImageIcon imageIcon20 = new ImageIcon(image);
                  Image newimg20 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg20);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "tgz":
                  image = ImageIO.read(new File("icons\\tgz.png"));
                  ImageIcon imageIcon21 = new ImageIcon(image);
                  Image newimg21 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg21);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "txt":
                  image = ImageIO.read(new File("icons\\txt.png"));
                  ImageIcon imageIcon22 = new ImageIcon(image);
                  Image newimg22 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg22);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "video":
                  image = ImageIO.read(new File("icons\\video.png"));
                  ImageIcon imageIcon24 = new ImageIcon(image);
                  Image newimg23 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg23);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "wav":
                  image = ImageIO.read(new File("icons\\wav.png"));
                  ImageIcon imageIcon23 = new ImageIcon(image);
                  Image newimg24 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg24);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "xlsx":
                  image = ImageIO.read(new File("icons\\xlsx.png"));
                  ImageIcon imageIcon25 = new ImageIcon(image);
                  Image newimg25 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg25);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "xlx":
                  image = ImageIO.read(new File("icons\\xlx.png"));
                  ImageIcon imageIcon26 = new ImageIcon(image);
                  Image newimg26 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg26);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "xml":
                  image = ImageIO.read(new File("icons\\xml.png"));
                  ImageIcon imageIcon27 = new ImageIcon(image);
                  Image newimg27 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg27);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                case "zip":
                  image = ImageIO.read(new File("icons\\zip.png"));
                  ImageIcon imageIcon28 = new ImageIcon(image);
                  
                  Image newimg28 = image.getScaledInstance(10, 10,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                  imageIcon = new ImageIcon(newimg28);  // transform it back
                  
                  
                  icon_button = new JButton(imageIcon);

                break;

                default:
                  // code block
            }   
            
            
            
         
            //icon_button.addMouseListener(mouseListener2);
            //icon_button.setVerticalTextPosition(SwingConstants.BOTTOM);
            //icon_button.setHorizontalTextPosition(SwingConstants.CENTER);
            //icon_button.setOpaque(false);
            //icon_button.setContentAreaFilled(false);
            //icon_button.setBorderPainted(true);
//            icon_button.setToolTipText(contents[i]);
            
             
            
            rows[i][0] = icon_button;
            //rows[i].addMouseListener(mouseListener2);
            //table.add(icon_button);
            //table.setValueAt(icon_button);
            
            
            i=i+1;
        }
        
        /*JTable table;
        TableCellRenderer tableRenderer;
        
        JTableButtonModel button_model = new JTableButtonModel(rows);
        
        System.out.println(button_model.getRows()[0][1]);
        
        
        table = new JTable(button_model);
        
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.setShowVerticalLines(false);

        tableRenderer = table.getDefaultRenderer(JButton.class);
        table.setDefaultRenderer(JButton.class, new JTableButtonRenderer(tableRenderer));

        JScrollPane tableScroll = new JScrollPane(table);
        
        Dimension d = tableScroll.getPreferredSize();
        tableScroll.setPreferredSize(new Dimension(500,20));

        rightPanel.add(tableScroll, BorderLayout.CENTER);
            */
        
       
        
        MouseListener mouseListener2 = new MouseAdapter() {
             
                public void mouseClicked(MouseEvent mouseEvent ){
                    Object o = mouseEvent.getSource();
                    flag_dir=0;
                    String buttonText = "", pathtext;
                    int row;

                    row = table.getSelectedRow();
                    pathtext = (String)rows[row][1];
                    System.out.println("pathtext is: "+pathtext);
                    
                    Object source = mouseEvent.getSource();

                    if (mouseEvent.getClickCount() == 2 && (mouseEvent.getButton() == MouseEvent.BUTTON1)) {
                       // JFileChooser choice = new JFileChooser();
                  
                        File file_to_open = new File(pathtext);
                        
                        if(file_to_open.isDirectory()){
                            directoryPath = new File(pathtext);
                            filepath = pathtext;
                            contents = directoryPath.list();
                            try{
                                Display();

                            }
                            catch(Exception e)  
                            {  
                                e.printStackTrace();  
                            }  
                            rightPanel.repaint();
                            rightPanel.revalidate();
                        }
                        else{
                            Desktop desktop = Desktop.getDesktop();
                            try{
                                desktop.open(file_to_open);
                            }
                            catch(Exception e)  
                            {  
                                e.printStackTrace();  
                            } 
                        }
                    }
                        
                }
            };

        
        TableCellRenderer tableRenderer;
        table = new JTable(new JTableButtonModel(rows));
        tableRenderer = table.getDefaultRenderer(JButton.class);
        table.setDefaultRenderer(JButton.class, new JTableButtonRenderer(tableRenderer));
        JScrollPane scrollPane = new JScrollPane(table);
        rightPanel.add(scrollPane, BorderLayout.CENTER);
        table.addMouseListener(mouseListener2);
        
        rightPanel.repaint();
        rightPanel.revalidate();
    }
}
